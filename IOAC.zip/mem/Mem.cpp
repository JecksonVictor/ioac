#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <sstream>

struct T_Configuracao {
	size_t Tamanho_Do_Bloco;
	size_t Numero_De_Linhas; //Cache
	size_t Numero_De_Blocos; //Memoria Principal
	size_t Mapeamento;
	size_t Numero_De_Conjuntos;
	size_t Politica_De_Substituicao;
	size_t Politica_De_Escrita;
};

struct T_Palavra {
	int conteudo;
	int endereco;
};

struct T_Bloco {
	std::vector< T_Palavra > bloco;
};

void printC(std::vector< T_Bloco > m, T_Configuracao config){
	std::cout << "Linha|Bloco|Endereco|Conteudo" << '\n';
	for (size_t i = 0; i < m.size(); i++) {
		for (size_t j = 0; j < m[i].bloco.size(); j++) {
			std::cout << i << " - ";
			std::cout << m[i].bloco[j].endereco/config.Tamanho_Do_Bloco << " - ";
			std::cout << m[i].bloco[j].endereco << " - ";
			std::cout << m[i].bloco[j].conteudo << '\n';
		}
	} std::cout << '\n';
}
void printP(std::vector< T_Bloco > m, T_Configuracao config){
	std::cout << "Bloco|Endereco|Conteudo" << '\n';
	for (size_t i = 0; i < m.size(); i++) {
		for (size_t j = 0; j < m[i].bloco.size(); j++) {
			std::cout << m[i].bloco[j].endereco/config.Tamanho_Do_Bloco << " - ";
			std::cout << m[i].bloco[j].endereco << " - ";
			std::cout << m[i].bloco[j].conteudo << '\n';
		}
	} std::cout << '\n';
}

void read(int _endereco, std::vector< T_Bloco > MC, std::vector< T_Bloco > MP, T_Configuracao config){
/*	if (config.Mapeamento == 1){ //Direto
		int pos = (_endereco%config.Numero_De_Linhas);
		if (MC[pos].bloco == MP[_endereco].bloco){
			std::cout << "HIT linha " << pos << std::endl;
		} else {
			std::cout << "MISS -> alocado na linha " << pos;
			if (MC[pos].bloco[0].endereco != -1){
				std::cout << "->  bloco " << MC[pos].bloco[0].endereco % config.Tamanho_Do_Bloco << " substituido \n";
			}
			MC[pos] = MC[_endereco];
		}
	}*/
}
/*
void write(int _endereco, int conteudo, std::vector< T_Bloco > MC, std::vector< T_Bloco > MP, T_Configuracao config){
	if (config.Politica_De_Escrita == 1){ //write back

	} else if (config.Politica_De_Escrita == 2){ //write through
		int pos = (_endereco%config.Numero_De_Linhas);
		if (MC[pos].bloco[0].endereco == -1){

		}
	}
}
*/
int main(int argc, char const *argv[]) {
	//* LER CONFIGURAÇÃO *//
	std::ifstream file;
	file.open("config.txt");
	if (!file.is_open()){
		std::cout << "Erro: Falta - Arquivo de configurações!" << '\n';
		return 0;
	}

	T_Configuracao configuracao;
	std::string aux;
	getline(file, aux);
	configuracao.Tamanho_Do_Bloco = std::stoi(aux);
	getline(file, aux);
	configuracao.Numero_De_Linhas = std::stoi(aux);
	getline(file, aux);
	configuracao.Numero_De_Blocos = std::stoi(aux);
	getline(file, aux);
	configuracao.Mapeamento = std::stoi(aux);
	getline(file, aux);
	configuracao.Numero_De_Conjuntos = std::stoi(aux);
	getline(file, aux);
	configuracao.Politica_De_Substituicao = std::stoi(aux);
	getline(file, aux);
	configuracao.Politica_De_Escrita = std::stoi(aux);

	file.close();

	//* Memórias Dec. *//
	std::vector< T_Bloco > Memoria_Cache;
	Memoria_Cache.resize(configuracao.Numero_De_Linhas);
	for (size_t i = 0; i < Memoria_Cache.size(); i++) {
		Memoria_Cache[i].bloco.resize(configuracao.Tamanho_Do_Bloco);
		for (size_t j = 0; j < Memoria_Cache[i].bloco.size(); j++) {
			Memoria_Cache[i].bloco[j].conteudo = -1;
			Memoria_Cache[i].bloco[j].endereco = -1;
		}
	}

	std::vector< T_Bloco > Memoria_Principal;
	Memoria_Principal.resize(configuracao.Numero_De_Blocos);
	for (size_t i = 0; i < Memoria_Principal.size(); i++) {
		Memoria_Principal[i].bloco.resize(configuracao.Tamanho_Do_Bloco);
		for (size_t j = 0; j < Memoria_Principal[i].bloco.size(); j++) {
			Memoria_Principal[i].bloco[j].conteudo = 0;
			Memoria_Principal[i].bloco[j].endereco = configuracao.Tamanho_Do_Bloco*i + j;
		}
	}

	while(true){
		std::string _comando;
		std::vector< std::string > comando;

		getline(std::cin, _comando);

		std::istringstream iss(_comando);
		while (iss) {
			std::string aux;
			iss >> aux;
			comando.push_back(aux);
		}

		if (comando.size() < 1) continue;

		if (comando[0] == "read" && comando.size() > 2){
			read(stoi(comando[1]), Memoria_Cache, Memoria_Principal, configuracao);
		} else if (comando[0] == "write" && comando.size() > 3){
			std::cout << "/* message 2*/" << '\n';
		} else if (comando[0] == "show"){
			printC(Memoria_Cache, configuracao);
			printP(Memoria_Principal, configuracao);
		}
	}

	return 0;
}
