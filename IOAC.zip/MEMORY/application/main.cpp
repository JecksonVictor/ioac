#include "Configuracao.h"
#include "Memoria_Cache.h"
#include "Memoria_Principal.h"

#include <string>

int main(int argc, char const *argv[]) {
	Config config;
	if (config.Ok != true){
		std::cout << "/* Missing config.txt file */" << '\n';
		return -1;
	}

	MemoriaPrincipal mem_principal(config.Tamanho_Do_Bloco, config.Numero_De_Blocos);
	MemoriaCache mem_cache(config.Tamanho_Do_Bloco, config.Numero_De_Linhas);

	std::cout << mem_principal << mem_cache << '\n';

	while(false){
		std::string _comando;
		std::vector< str::string > comando;

		getline(std::cin, _comando);

		std::istringstream iss(_comando);
		while (iss) {
			std::string aux;
			iss >> aux;
			comando.push_back(aux);
		}

		if (comando.size() < 1) continue;

			   if (comando[0] == "read" && comando.size() > 1){
				   mem_cache.read(stoi(comando[1]), mem_principal, config);
		} else if (comando[0] == "write" && comando.size() > 2){
					mem_cache.write(stoi(comando[1]), stoi(comando[2]), mem_principal, config);
		} else if (comando[0] == "show"){
			std::cout << mem_cache << mem_principal << std::endl;
		}
	}
	return 0;
}
