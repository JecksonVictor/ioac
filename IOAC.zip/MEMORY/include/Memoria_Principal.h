#ifndef _MemoriaPrincipal_
#define _MemoriaPrincipal_

	#include "Bloco.h"

	class MemoriaPrincipal {
	public:
		std::vector< Bloco > data_principal;

		MemoriaPrincipal (size_t Tamanho_Do_Bloco, size_t Numero_De_Blocos){
			data_principal.resize(Numero_De_Blocos);
			for (size_t i = 0; i < data_principal.size(); i++) {
				data_principal[i].bloco.resize(Tamanho_Do_Bloco);
				for (size_t j = 0; j < data_principal[i].bloco.size(); j++) {
					data_principal[i].bloco[j].conteudo = 0;
					data_principal[i].bloco[j].endereco = 0;
				}
			}
		}

		friend std::ostream & operator << (std::ostream & out, MemoriaPrincipal d){
			out << "/* Memoria Principal */" << '\n';
			for (size_t i = 0; i < d.data_principal.size(); i++) {
				for (size_t j = 0; j < d.data_principal[i].bloco.size(); j++) {
					out << d.data_principal[i].bloco[j].conteudo << ' ';
				} out << std::endl;
			} out << std::endl;

			return out;
		}
	};

#endif
