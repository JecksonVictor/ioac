#include <fstream>
#include <iostream>

class Config {
public:
	bool Ok;
	size_t Tamanho_Do_Bloco;
	size_t Numero_De_Linhas; //Cache
	size_t Numero_De_Blocos; //Memoria Principal
	size_t Mapeamento;
	size_t Numero_De_Conjuntos;
	size_t Politica_De_Substituicao;
	size_t Politica_De_Escrita;

	Config (){
		std::ifstream file;
		file.open("config/config.txt");
		if (!file.is_open()){
			Ok = false;
		} else {
			Ok = true;

			std::string aux;
			getline(file, aux);
			Tamanho_Do_Bloco = std::stoi(aux);
			getline(file, aux);
			Numero_De_Linhas = std::stoi(aux);
			getline(file, aux);
			Numero_De_Blocos = std::stoi(aux);
			getline(file, aux);
			Mapeamento = std::stoi(aux);
			getline(file, aux);
			Numero_De_Conjuntos = std::stoi(aux);
			getline(file, aux);
			Politica_De_Substituicao = std::stoi(aux);
			getline(file, aux);
			Politica_De_Escrita = std::stoi(aux);
		}
		file.close();
	}
	virtual ~Config () {};

	friend std::ostream & operator << (std::ostream & out, Config _config){
		if (!_config.Ok)
			return out;

		std::cout << _config.Tamanho_Do_Bloco << '\n';
		std::cout << _config.Numero_De_Linhas << '\n';
		std::cout << _config.Numero_De_Blocos << '\n';
		std::cout << _config.Mapeamento << '\n';
		std::cout << _config.Numero_De_Conjuntos << '\n';
		std::cout << _config.Politica_De_Substituicao << '\n';
		std::cout << _config.Politica_De_Escrita << '\n';

		return out;
	}
};

/*
Tamanho do bloco (em número de palavras)
Numero de linhas da cache
Numero de blocos da memória principal
Mapeamento (1 – Direto; 2 – Totalmente Associativo; 3 – Parcialmente Associativo)
Numero de conjuntos (caso não seja Parcialmente Associativo, ler o valor normalmente mas desconsidere-o)
Política de substituição (1 – Aleatório; 2 – FIFO; 3 – LFU; 4 – LRU)
Política de Escrita (1 – Write-back; 2 – Write-Through)
*/
