#ifndef _Bloco_
#define _Bloco_

	#include <vector>

	#include "Palavra.h"

	struct Bloco {
		std::vector< Palavra > bloco;
		bool on;
	};

#endif
