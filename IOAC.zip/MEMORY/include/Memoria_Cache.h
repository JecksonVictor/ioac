#ifndef _MemoriaCache_
#define _MemoriaCache_

	#include "Bloco.h"
	#include "Configuracao.h"

	class MemoriaCache {
	public:
		std::vector< Bloco > data_cache;

		MemoriaCache (size_t Tamanho_Do_Bloco, size_t Numero_De_Linhas){
			data_cache.resize(Numero_De_Linhas);
			for (size_t i = 0; i < data_cache.size(); i++) {
				data_cache[i].bloco.resize(Tamanho_Do_Bloco);
				for (size_t j = 0; j < data_cache[i].bloco.size(); j++) {
					data_cache[i].bloco[j].conteudo = 0;
					data_cache[i].bloco[j].endereco = 0;
				} data_cache[i].on = false;
			}
		}

		friend std::ostream & operator << (std::ostream & out, MemoriaCache d){
			out << "/* Memoria Cache */" << '\n';
			for (size_t i = 0; i < d.data_cache.size(); i++) {
				for (size_t j = 0; j < d.data_cache[i].bloco.size(); j++) {
					out << d.data_cache[i].bloco[j].conteudo << ' ';
				} out << std::endl;
			} out << std::endl;
			return out;
		}

		void read(int _endereco, MemoriaPrincipal _mem_principal, Configuracao _config){
			if (_config.Mapeamento == 1){ //Direto
				int pos = (_endereco%_config.Numero_De_Linhas);
				if (data_cache[pos] == true){
					std::cout << "HIT linha " << pos << std::endl;
				} else {
					std::cout << "MISS -> alocado na linha " << pos;
					mem_cache[pos] = _mem_principal[_endereco];
				}
			} else if (_config.Mapeamento == 2){ //T.Assoc
				int pos = -1;
				for (size_t i = 0; i < mem_cache.size(); i++) {
					if (mem_cache[i].bloco == _mem_principal[_endereco].bloco){
						pos = i;
						break;
					}
				}
				if (i != -1){
					std::cout << "Hit linha " << pos << '\n';
				} else {
					if (_config.Politica_De_Substituicao == 0){

					} else if(_config.Politica_De_Substituicao == 1){

					} else if(_config.Politica_De_Substituicao == 2) {

					} else if(_config.Politica_De_Substituicao == 3) {

					}
				}
			} else if (_config.Mapeamento == 3){ //P.Asssoc
				
			}
		}

		void write(){

		}
	};

#endif
