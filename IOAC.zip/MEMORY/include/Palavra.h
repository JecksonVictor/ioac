#ifndef _Palavra_
#define _Palavra_

	struct Palavra {
		size_t endereco;
		int conteudo;
	};

#endif
