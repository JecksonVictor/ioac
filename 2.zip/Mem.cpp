#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <sstream>

int wb_end = -1;
int wb_cont;

struct T_Configuracao {
	size_t Tamanho_Do_Bloco;
	size_t Numero_De_Linhas; //Cache
	size_t Numero_De_Blocos; //Memoria Principal
	size_t Mapeamento;
	size_t Numero_De_Conjuntos;
	size_t Politica_De_Substituicao;
	size_t Politica_De_Escrita;
};

struct T_Palavra {
	int conteudo;
	int endereco;
};

struct T_Bloco {
	std::vector< T_Palavra > bloco;
};

void printC(std::vector< T_Bloco > m, T_Configuracao config){
	std::cout << "Linha|Bloco|Endereco|Conteudo" << '\n';
	for (size_t i = 0; i < m.size(); i++) {
		for (size_t j = 0; j < m[i].bloco.size(); j++) {
			std::cout << i << " - ";
			std::cout << m[i].bloco[j].endereco/config.Tamanho_Do_Bloco << " - ";
			std::cout << m[i].bloco[j].endereco << " - ";
			std::cout << m[i].bloco[j].conteudo << '\n';
		}
	} std::cout << '\n';
}
void printP(std::vector< T_Bloco > m, T_Configuracao config){
	std::cout << "Bloco|Endereco|Conteudo" << '\n';
	for (size_t i = 0; i < m.size(); i++) {
		for (size_t j = 0; j < m[i].bloco.size(); j++) {
			std::cout << m[i].bloco[j].endereco/config.Tamanho_Do_Bloco << " - ";
			std::cout << m[i].bloco[j].endereco << " - ";
			std::cout << m[i].bloco[j].conteudo << '\n';
		}
	} std::cout << '\n';
}
// std::cout << "Here" << std::endl;
void read(int _endereco, std::vector< T_Bloco >& MC, std::vector< T_Bloco >& MP, std::vector<int>& data_cache,T_Configuracao config){
	if (config.Mapeamento == 1){ //Direto  
		int mpbloco = _endereco/config.Tamanho_Do_Bloco;
		int pos = (mpbloco%config.Numero_De_Linhas);

		if (data_cache[pos] == _endereco){
			std::cout << "HIT linha " << pos << std::endl;
		} else { 
			std::cout << "MISS -> alocado na linha " << pos << std::endl;
			if (data_cache[pos] != -1){
				std::cout << "->  bloco " << data_cache[pos] << " substituido \n";
			}
			for (int i = 0; i < config.Tamanho_Do_Bloco; ++i)
			{
				MC[pos].bloco[i].endereco = MP[mpbloco].bloco[i].endereco;
				MC[pos].bloco[i].conteudo = MP[mpbloco].bloco[i].conteudo;
			}
			data_cache[pos] = mpbloco;
		}
	} else if (config.Mapeamento == 2){ //Totalmente Associativo
		int mpbloco = _endereco/config.Tamanho_Do_Bloco;

		for (int i = 0; i < data_cache.size(); ++i)
		{
			if (data_cache[i] == mpbloco){
				std::cout << "HIT linha " << i << std::endl;
				return;
			}
		}
		//SE não estiver na cache, escreve
	} else if (config.Mapeamento == 3){ //Parcialmente Associativo
		int mpbloco = _endereco/config.Tamanho_Do_Bloco;
		int set = mpbloco%config.Numero_De_Conjuntos;
		int elempset = config.Numero_De_Linhas/config.Numero_De_Conjuntos;
		int pelemset = set*elempset;

		for (int i = pelemset; i < pelemset+elempset-1; ++i)
		{
			if (data_cache[i] == mpbloco){
				std::cout << "HIT linha " << i << std::endl;
				return;
			}
		}
		//SE não estiver na cache, escreve
	}
}

void write(int _endereco, int _conteudo, std::vector< T_Bloco >& MC, std::vector< T_Bloco >& MP, std::vector<int>& data_cache, T_Configuracao config){
	if (config.Politica_De_Escrita == 1){ //write back
		if (wb_end != -1){
			int mpbloco = wb_end/config.Tamanho_Do_Bloco;
			int pos = (mpbloco%config.Numero_De_Blocos);

			MP[mpbloco].bloco[pos].conteudo = we_cont;
		}
		wb_end = _endereco;
		wb_cont = _conteudo;

		int mpbloco = _endereco/config.Tamanho_Do_Bloco;
		int pos = (mpbloco%config.Numero_De_Blocos);

		read(_endereco, MC, MP, data_cache, config);
		

	} else if (config.Politica_De_Escrita == 2){ //write through
		int mpbloco = _endereco/config.Tamanho_Do_Bloco;
		int pos = (mpbloco%config.Numero_De_Linhas);

		int ind = _endereco%config.Tamanho_Do_Bloco;
		MP[mpbloco].bloco[ind].conteudo = _conteudo;
		read(_endereco, MC, MP, data_cache, config);
	}
}

int main(int argc, char const *argv[]) {
	//* LER CONFIGURAÇÃO *//
	std::ifstream file;
	file.open("config.txt");
	if (!file.is_open()){
		std::cout << "Erro: Falta - Arquivo de configurações!" << '\n';
		return 0;
	}

	T_Configuracao configuracao;
	std::string aux;
	getline(file, aux);
	configuracao.Tamanho_Do_Bloco = std::stoi(aux);
	getline(file, aux);
	configuracao.Numero_De_Linhas = std::stoi(aux);
	getline(file, aux);
	configuracao.Numero_De_Blocos = std::stoi(aux);
	getline(file, aux);
	configuracao.Mapeamento = std::stoi(aux);
	getline(file, aux);
	configuracao.Numero_De_Conjuntos = std::stoi(aux);
	getline(file, aux);
	configuracao.Politica_De_Substituicao = std::stoi(aux);
	getline(file, aux);
	configuracao.Politica_De_Escrita = std::stoi(aux);

	file.close();

	//* Memórias Dec. *//
	std::vector< T_Bloco > Memoria_Cache;
	Memoria_Cache.resize(configuracao.Numero_De_Linhas);
	for (size_t i = 0; i < Memoria_Cache.size(); i++) {
		Memoria_Cache[i].bloco.resize(configuracao.Tamanho_Do_Bloco);
		for (size_t j = 0; j < Memoria_Cache[i].bloco.size(); j++) {
			Memoria_Cache[i].bloco[j].conteudo = -1;
			Memoria_Cache[i].bloco[j].endereco = -1;
		}
	}

	std::vector< T_Bloco > Memoria_Principal;
	Memoria_Principal.resize(configuracao.Numero_De_Blocos);
	for (size_t i = 0; i < Memoria_Principal.size(); i++) {
		Memoria_Principal[i].bloco.resize(configuracao.Tamanho_Do_Bloco);
		for (size_t j = 0; j < Memoria_Principal[i].bloco.size(); j++) {
			Memoria_Principal[i].bloco[j].conteudo = 0;
			Memoria_Principal[i].bloco[j].endereco = configuracao.Tamanho_Do_Bloco*i + j;
		}
	}

	// Blocos no Cache
	std::vector<int> data_cache;
	data_cache.resize(configuracao.Numero_De_Linhas, -1);

	while(true){
		std::string _comando;
		std::vector< std::string > comando;

		getline(std::cin, _comando);

		std::istringstream iss(_comando);
		while (iss) {
			std::string aux;
			iss >> aux;
			comando.push_back(aux);
		}

		if (comando.size() < 1) continue;

		if (comando[0] == "read" && comando.size() > 2){
			read(stoi(comando[1]), Memoria_Cache, Memoria_Principal, data_cache, configuracao);
		} else if (comando[0] == "write" && comando.size() > 3){
			write(stoi(comando[1]), stoi(comando[2]), Memoria_Cache, Memoria_Principal, data_cache, configuracao);
		} else if (comando[0] == "show"){
			printC(Memoria_Cache, configuracao);
			printP(Memoria_Principal, configuracao);
		}
	}

	return 0;
}
