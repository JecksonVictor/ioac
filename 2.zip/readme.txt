Projeto IOAC - Simulador de Cache - T01
Aluno: Jeckson Victor de Oliveira [2015031132]

Para executar:
	./mem

Para compilar:
	g++ -std=c++11 Mem.cpp -o mem

Do funcionamento:
	Lê um arquivo chamado config.txt, com as configurações base, que deve ficar na mesma pasta do executável.
	Então o programa cria dois vetores de blocos (que são vetores de palavras) para representar a cache e a memória principal. Há também um vetor auxiliar chamado data_cache, que guarda os elementos da memória principal que estão na cache.
	Ao executar, o programa esperará 3 comandos possíveis do teclado, read, write e show, com seus parâmetros definidos no documento de instruções do projeto.
